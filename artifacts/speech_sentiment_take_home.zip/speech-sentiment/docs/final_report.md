# Speech Emotion and Sentiment Recognition: Approach and Results

## Approach and Design Motivation

Speech conveys information through both words and vocal expression. I compared an acoustic baseline, a simple audio-and-text fusion model, and a continuous audio representation to measure their quality and latency trade-offs.

I chose MELD as the primary dataset because its utterances have audio, transcripts, three-class sentiment labels, and seven-class emotion labels. This supports both tasks on the same selected examples.

### Emotion2Vec audio-only

Emotion2Vec Base provides the acoustic baseline. Its frozen frame-level representations are mean-pooled and passed to a small MLP classifier.

### Emotion2Vec + Text

This system combines the Emotion2Vec acoustic embedding with a MiniLM embedding of the local ASR transcript. The two vectors are concatenated and passed to the same MLP family. It tests whether lexical information complements tone and prosody without changing the fusion architecture.

### Continuous Mimi

Continuous Mimi provides an audio-native alternative. The system mean-pools continuous Mimi latents and classifies them directly, without a separate ASR and text-encoding branch.

### GPT Realtime

GPT Realtime was tried qualitatively on a small number of recordings as a larger audio-native reference. These observations are not a controlled MELD test result and are excluded from the quantitative tables below.

## Key Trade-offs

For three-class sentiment, Emotion2Vec + Text achieved the highest Macro-F1 and accuracy. Its mean latency was substantially higher, with ASR accounting for most of the measured time. Continuous Mimi was faster on the tested hardware and did not require the ASR/text pipeline.

| System | Macro-F1 | Weighted-F1 | Accuracy | Mean latency |
|---|---:|---:|---:|---:|
| Emotion2Vec audio-only | 0.430 | 0.450 | 44.5% | 0.144 s |
| Emotion2Vec + Text | **0.528** | **0.517** | **52.0%** | 0.847 s |
| Continuous Mimi | 0.448 | 0.463 | 46.0% | **0.097 s** |

The same ordering in speed and quality does not hold identically for seven-class emotion. Audio + Text remained the most accurate, while Mimi came close in Macro-F1 at lower local latency.

| System | Macro-F1 | Weighted-F1 | Accuracy | Mean latency |
|---|---:|---:|---:|---:|
| Emotion2Vec audio-only | 0.179 | 0.269 | 24.0% | 0.146 s |
| Emotion2Vec + Text | **0.262** | **0.403** | **39.0%** | 0.887 s |
| Continuous Mimi | 0.250 | 0.370 | 36.0% | **0.079 s** |

These latency measurements used the same Apple M1 Pro CPU and batch size of one, with one warm-up utterance. They measure complete-utterance inference, not streaming performance.

## Evaluation

The MELD experiment uses official train/dev/test boundaries and a fixed, seed-42 stratified subset of 1,000 / 200 / 200 utterances. Sampling is stratified by sentiment. Every system within a task uses the same selected examples; the included split ID list and sample hashes support verification. Classifier heads use weighted cross-entropy and validation Macro-F1 for checkpoint selection. The test set is not used for model selection.

MELD sentiment train / validation / test counts are 295 / 471 / 234, 73 / 85 / 42, and 64 / 96 / 40 for negative / neutral / positive. The emotion labels are evaluated on those same utterances, but the sentiment-stratified sample yields only 3 fear and 7 disgust examples in the test set.

### CREMA-D follow-up

As a separate speaker-independent experiment, I trained six-class classifier heads on 1,000 CREMA-D training utterances while keeping the pretrained encoders frozen. Validation Macro-F1 on 200 speaker-disjoint validation utterances selected each checkpoint; final metrics use the same fixed 200 speaker-disjoint test utterances. The results are separate from the primary MELD benchmark:

| System | Macro-F1 | Weighted-F1 | Accuracy |
|---|---:|---:|---:|
| Emotion2Vec audio-only | 0.649 | 0.647 | 65.0% |
| Emotion2Vec + Text | 0.643 | 0.643 | 64.5% |
| Continuous Mimi | 0.644 | 0.643 | 64.5% |

This result differs from the MELD comparison and suggests that the relative value of lexical and acoustic features depends on the dataset and speech style. CREMA-D is not part of the primary MELD benchmark. Its scripts and result artifacts are included separately in [`artifacts/crema_d_supervised/`](../artifacts/crema_d_supervised/); the audio is not redistributed.

### Interactive demo

The demo lets a user record or upload one utterance and run the same audio through the three local systems. It displays predictions, probabilities, latency, and the ASR transcript for the fused system. It is intended for qualitative exploration, not as an additional held-out evaluation set.

## Known Limitations and Failure Modes

1. **Limited evaluation data.** The main benchmark uses only 200 MELD test utterances from scripted television dialogue. The official splits reuse actors, so this is not a speaker-independent evaluation.
2. **Modest predictive performance.** The best sentiment result is 52.0% accuracy / 0.528 Macro-F1. The best seven-class emotion result is 39.0% accuracy / 0.262 Macro-F1.
3. **Rare emotion classes are unstable.** The test set has only 3 fear and 7 disgust examples. All three models missed all fear examples.
4. **Neutral sentiment is often confused.** Emotion2Vec + Text predicted negative for 38 of the 96 gold-neutral test utterances.
5. **Sentiment and emotion can disagree.** They are separate classifiers trained for different label spaces; no consistency constraint links their outputs. In an out-of-dataset text sanity check, the text-only classifier assigned 48.8% probability to positive and 43.8% to negative for “I lost my laptop last week, it's so sad.” This example has no MELD gold label and is illustrative, not part of the benchmark.
6. **ASR adds latency and can introduce errors.** In the sentiment benchmark, ASR took about 0.715 s of the fusion system's 0.847 s mean latency. Recognition errors can affect the text embedding.
7. **Displayed probabilities are uncalibrated.** The demo shows softmax scores, not calibrated estimates of correctness.
8. **The demo is not streaming.** All three systems wait for a complete utterance before producing a result.

## What I Would Explore Next

1. **Streaming inference.** Adapt Continuous Mimi to process audio as it arrives and measure latency and emotion changes over partial utterances.
2. **Selective conversational context.** A simple previous-turn context experiment reduced emotion Macro-F1 from 0.262 to 0.203 on this subset. I would next test speaker-aware selection of relevant history rather than concatenating a fixed number of prior turns.
3. **Controlled audio-native foundation model evaluation.** GPT Realtime was only explored qualitatively. With adequate API budget, I would evaluate a frozen prompt on the same MELD test split and compare its quality separately from local latency.
4. **Robustness and calibration.** Evaluate across additional speakers and recording conditions, then assess whether displayed confidence scores can be calibrated.

Detailed protocols and class-level tables are in the [sentiment results](results.md), [emotion results](emotion_results.md), and [sentiment diagnostic](sentiment_diagnostic.md). The main report artifacts and split IDs are in [`artifacts/final/`](../artifacts/final/).
